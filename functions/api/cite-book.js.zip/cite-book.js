import dotenv from 'dotenv'
dotenv.config()

/**
 * Stringifies the body and creates a JSON response
 */
export function createResponse(uuid, citationType, citationInfo) {
    // Convert undefined values to null
    const citation = {
        uuid: uuid || null,
        citationType: citationType || null,
        citationInfo: {
            authors: citationInfo.authors || null,
            sourceTitle: citationInfo.sourceTitle || null,
            publisher: citationInfo.publisher || null,
            publicationDate: citationInfo.publicationDate || null,
            accessDate: citationInfo.accessDate || null
        }
    };

    // Convert undefined date components to null
    if (citation.citationInfo.publicationDate) {
        citation.citationInfo.publicationDate = citation.citationInfo.publicationDate.map(dateObj => ({
            context: {
                prefix: dateObj.context.prefix || null,
                matchedText: dateObj.context.matchedText || null
            },
            date: {
                year: dateObj.date.year || null,
                month: dateObj.date.month || null,
                day: dateObj.date.day || null
            }
        }));
    }

    // Convert undefined accessDate components to null
    if (citation.citationInfo.accessDate) {
        citation.citationInfo.accessDate = {
            year: citation.citationInfo.accessDate.year || null,
            month: citation.citationInfo.accessDate.month || null,
            day: citation.citationInfo.accessDate.day || null
        };
    }

    return new Response(JSON.stringify(citation), {
        headers: {
            "content-type": "application/json"
        }
    });
}
const api_key = process.env.API_KEY;

/**
 * Fetch book information from the Google Books API
 */
async function fetchBookInfo(isbn) {
    const apiUrl = `https://www.googleapis.com/books/v1/volumes?q=isbn:${isbn}&key=${api_key}`;
    const response = await fetch(apiUrl);
    if (!response.ok) {
        throw new Error(`Failed to fetch book information from Google Books API: ${response.statusText}`);
    }
    return await response.json();
}

/**
 * Generate citation for the book
 */
function generateCitation(bookInfo) {
    const volumeInfo = bookInfo.volumeInfo;
    const authors = volumeInfo.authors ? volumeInfo.authors.join(', ') : 'Unknown author';
    const title = volumeInfo.title || 'Unknown title';
    const publisher = volumeInfo.publisher || 'Unknown publisher';
    const publishedDate = volumeInfo.publishedDate || 'Unknown date';
    const citation = `${authors}. (${publishedDate}). ${title}. ${publisher}.`;
    return citation;
}

/**
 * This function will be invoked on all requests no matter the request method.
 * https://developers.cloudflare.com/pages/functions/api-reference
 */
export async function onRequest(context) {
    const url = new URL(context.request.url);
    const isbn = url.searchParams.get('isbn');

    // Ensure the request has an `isbn` query parameter
    if (!isbn) {
        return createResponse({
            error: "No ISBN provided"
        });
    }

    // Validate ISBN format (basic check for numeric characters and length)
    const isValidISBN = /^[0-9]{10}$|^[0-9]{13}$/.test(isbn);
    if (!isValidISBN) {
        return createResponse({
            error: "Invalid ISBN format"
        });
    }

    try {
        // Fetch book information from Google Books API
        const bookInfo = await fetchBookInfo(isbn);

        // Check if bookInfo contains any items
        if (!bookInfo.items || bookInfo.items.length === 0) {
            return createResponse({
                error: "Book not found"
            });
        }

        // Generate citation for the book
        const citation = generateCitation(bookInfo.items[0]);

        return createResponse({
            success: true,
            citation: citation
        });
    } catch (error) {
        return createResponse({
            error: error.message || "Failed to fetch book information or generate citation"
        });
    }
}