import axios from 'axios';
import { JSDOM } from 'jsdom';

// Function to check if a URL is invalid
function isUrlInvalid(url) {
    // Regular expression to validate URL format
    const urlPattern = /^(http|https):\/\/[^ "]+$/;

    // Check if URL matches the pattern
    return !urlPattern.test(url);
}

export async function onRequest(request) {
    // Extract URL from request parameters
    const { url } = request.query;

    // Check if URL is provided and valid
    if (!url || isUrlInvalid(url)) {
        return new Response("Invalid URL", { status: 400 });
    }

    try {
        // Fetch website data
        const response = await axios.get(url);

        // Check if fetching is successful
        if (response.status !== 200) {
            return new Response(`Failed to fetch website data: ${response.statusText}`, { status: response.status });
        }

        // Parse HTML content using JSDOM
        const dom = new JSDOM(response.data);
        const document = dom.window.document;

        // Extract important information
        const title = document.querySelector('title').textContent;
        const description = document.querySelector('meta[name="description"]').getAttribute('content');
        const author = document.querySelector('meta[name="author"]').getAttribute('content');
        const keywords = document.querySelector('meta[name="keywords"]').getAttribute('content');

        // Construct JSON object with extracted information
        const data = {
            title,
            description,
            author,
            keywords
        };

        // Make a request to the specified endpoint (http://localhost:4321/cite-website)
        const endpoint = 'http://localhost:4321/cite-website';
        const endpointResponse = await axios.post(endpoint, data, {
            headers: {
                'Content-Type': 'application/json'
            }
        });

        // Check if the request to the endpoint was successful
        if (endpointResponse.status !== 200) {
            return new Response(`Failed to send data to endpoint: ${endpointResponse.statusText}`, { status: endpointResponse.status });
        }

        // Return a success response
        return new Response('Data sent to endpoint successfully', { status: 200 });
    } catch (error) {
        return new Response(`Error: ${error.message}`, { status: 500 });
    }
}







/* cite-website
Receives a URL, fetches website data, extracts important information (cheerio), return a JSON object

*/